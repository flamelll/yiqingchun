package com.test.bean;

public class Shiwu {
private String classes;
private String name;
private String calory;
public String getClasses() {
	return classes;
}
public void setClasses(String classes) {
	this.classes = classes;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCalory() {
	return calory;
}
public void setCalory(String calory) {
	this.calory = calory;
}
}
