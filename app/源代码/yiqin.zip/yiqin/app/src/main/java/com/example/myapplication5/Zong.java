package com.example.myapplication5;

public class Zong {
    private String name;

    public String getSzong() {
        return szong;
    }

    public void setSzong(String szong) {
        this.szong = szong;
    }

    private String szong;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getZong() {
        return zong;
    }

    public void setZong(Integer zong) {
        this.zong = zong;
    }

    private Integer zong;
}
