package com.example.myapplication5;

import android.app.Activity;
import android.os.Bundle;


public class regimen_1 extends Activity {
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab01_3_1);


    }
}
