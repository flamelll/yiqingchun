package com.example.myapplication5;

public class Chart {
    private String weight;

    public String getWeight() {
        return weight;
    }
    public void setWeight(String weight) {
        this.weight = weight;
    }

}
