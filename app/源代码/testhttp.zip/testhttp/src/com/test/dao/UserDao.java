package com.test.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.test.bean.Shiwu;
import com.test.bean.User;
import com.test.util.DBUtil;
public class UserDao {
	public List<User> select(String name){
		Connection conn = DBUtil.getConn(); //�������ݿ�
	    List<User> list = new ArrayList<User>();
	    try {
	        String sql="select * from user where name like '%"+name+"%' ";
	        Statement pstmt = (Statement) conn.createStatement();
	        ResultSet rs = (ResultSet) pstmt.executeQuery(sql);
	        while(rs.next()) {
	        	User User=new User();
	        	User.setName(rs.getString("name"));
	        	User.setPassword(rs.getString("password"));
	        	User.setVname(rs.getString("vname"));
	        	User.setWeight(rs.getString("weight"));
	        	User.setHeight(rs.getString("height"));
	        	User.setYear(rs.getString("year"));
	        	User.setSchool(rs.getString("school"));
	        	User.setSex(rs.getString("sex"));
	            list.add(User);
	        }
	        rs.close();
	        pstmt.close();
	        conn.close();

	    }catch(SQLException e) {
	        e.printStackTrace();
	    }
	    return list;
	}
}
