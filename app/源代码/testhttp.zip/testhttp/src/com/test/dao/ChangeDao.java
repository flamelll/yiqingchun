package com.test.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.test.util.DBUtil;

public class ChangeDao {
	public static boolean changePassword(String name,String npassword) {

		String sql="update user set password = '"+ npassword +"' where name = '"+ name +"'";
		Connection conn = DBUtil.getConn();
	    Statement state = null;
	    boolean f = false;
	    int a = 0;
	    try {
	        state = conn.createStatement();
	        state.executeUpdate(sql);
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        //�ر�����
	        DBUtil.close(state, conn);
	    }
	    if (a > 0) {
	        f = true;
	    }
	    return f;
	}
}
