package com.test.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.test.bean.Date;
import com.test.bean.Shiwu;
import com.test.util.DBUtil;

public class DateShowDao {
	public List<Date> select(){
		Connection conn = DBUtil.getConn(); //�������ݿ�
	    List<Date> list = new ArrayList<Date>();
	    try {
	        String sql="select * from date";
	        Statement pstmt = (Statement) conn.createStatement();
	        ResultSet rs = (ResultSet) pstmt.executeQuery(sql);
	        while(rs.next()) {
	        	Date Date=new Date();
	        	Date.setType(rs.getString("type"));
	        	Date.setTime(rs.getString("time"));
	        	Date.setDate(rs.getString("date"));
	        	Date.setName(rs.getString("name"));
	            list.add(Date);
	        }
	        rs.close();
	        pstmt.close();
	        conn.close();

	    }catch(SQLException e) {
	        e.printStackTrace();
	    }
	    return list;
	}
	public List<Date> select1(String name){
		Connection conn = DBUtil.getConn(); //�������ݿ�
	    List<Date> list = new ArrayList<Date>();
	    try {
	        String sql="select * from date where name like '%"+name+"%' ";
	        Statement pstmt = (Statement) conn.createStatement();
	        ResultSet rs = (ResultSet) pstmt.executeQuery(sql);
	        while(rs.next()) {
	        	Date Date=new Date();
	        	Date.setType(rs.getString("type"));
	        	Date.setTime(rs.getString("time"));
	        	Date.setDate(rs.getString("date"));
	        	Date.setName(rs.getString("name"));
	            list.add(Date);
	        }
	        rs.close();
	        pstmt.close();
	        conn.close();

	    }catch(SQLException e) {
	        e.printStackTrace();
	    }
	    return list;
	}
}
