package com.test.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.test.bean.Shiwu;
import com.test.util.DBUtil;


public class ShowDao {
	public List<Shiwu> select(){
		Connection conn = DBUtil.getConn(); //�������ݿ�
	    List<Shiwu> list = new ArrayList<Shiwu>();
	    try {
	        String sql="select * from reliang";
	        Statement pstmt = (Statement) conn.createStatement();
	        ResultSet rs = (ResultSet) pstmt.executeQuery(sql);
	        while(rs.next()) {
	        	Shiwu Shiwu=new Shiwu();
	        	Shiwu.setClasses(rs.getString("classes"));
	        	Shiwu.setName(rs.getString("name"));
	        	Shiwu.setCalory(rs.getString("calory"));
	            list.add(Shiwu);
	        }
	        rs.close();
	        pstmt.close();
	        conn.close();

	    }catch(SQLException e) {
	        e.printStackTrace();
	    }
	    return list;
	}
	public List<Shiwu> select1(String name){
		Connection conn = DBUtil.getConn(); //�������ݿ�
	    List<Shiwu> list1 = new ArrayList<Shiwu>();
	    try {
	        String sql="select * from reliang where name like '%"+name+"%' ";
	        Statement pstmt = (Statement) conn.createStatement();
	        ResultSet rs = (ResultSet) pstmt.executeQuery(sql);
	        while(rs.next()) {
	        	Shiwu Shiwu=new Shiwu();
	        	Shiwu.setClasses(rs.getString("classes"));
	        	Shiwu.setName(rs.getString("name"));
	        	Shiwu.setCalory(rs.getString("calory"));
	            list1.add(Shiwu);
	        }
	        rs.close();
	        pstmt.close();
	        conn.close();
	        System.out.println("ShowDaoselect1");

	    }catch(SQLException e) {
	        e.printStackTrace();
	    }
	    return list1;
	}

	
}