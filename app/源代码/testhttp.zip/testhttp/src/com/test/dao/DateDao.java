package com.test.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.cj.util.Util;
import com.test.util.DBUtil;

public class DateDao {

    public boolean addDate(String type,String time,String date,String name) {
    	String sql="insert into date(type, time, date, name) values('" + type + "','" + time + "','" + date + "','"+ name +"')";
       //�������ݿ�����
       Connection conn = DBUtil.getConn();
       Statement state = null;
       boolean f = false;
       int a = 0;
       try {
           state = conn.createStatement();
           state.executeUpdate(sql);
       } catch (Exception e) {
           e.printStackTrace();
       } finally {
           //�ر�����
           DBUtil.close(state, conn);
       }
       if (a > 0) {
           f = true;
       }
       return f;
   }

}
