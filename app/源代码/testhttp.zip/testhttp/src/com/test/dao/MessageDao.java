package com.test.dao;

import java.sql.Connection;
import java.sql.Statement;

import com.test.util.DBUtil;

public class MessageDao {
	 public boolean Message(String name,String password,String id,String weight,String height,String year,String sex,String school) {
	    	String sql="update user set vname = '"+ id +"' &weight = '"+ weight +"'&height = '"+ height +"'&year = '"+ year +"'&sex = '"+ sex +"'&school = '"+ school +"'where name = '"+ name +"'";
	       //�������ݿ�����
			Connection conn = DBUtil.getConn();
		    Statement state = null;
		    boolean f = false;
		    int a = 0;
		    try {
		        state = conn.createStatement();
		        state.executeUpdate(sql);
		    } catch (Exception e) {
		        e.printStackTrace();
		    } finally {
		        //�ر�����
		        DBUtil.close(state, conn);
		    }
		    if (a > 0) {
		        f = true;
		    }
		    return f;
	   }

}
