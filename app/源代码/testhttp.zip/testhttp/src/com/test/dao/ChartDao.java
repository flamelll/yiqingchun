package com.test.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.test.util.DBUtil;

import com.test.bean.Chart;


public class ChartDao {
	 public boolean Chart(String name,String weight) {
	    	String sql="insert into chart(name,weight) values('"+ name +"','"+ weight+"')";
	       //�������ݿ�����
			Connection conn = DBUtil.getConn();
		    Statement state = null;
		    boolean f = false;
		    int a = 0;
		    try {
		        state = conn.createStatement();
		        state.executeUpdate(sql);
		    } catch (Exception e) {
		        e.printStackTrace();
		    } finally {
		        //�ر�����
		        DBUtil.close(state, conn);
		    }
		    if (a > 0) {
		        f = true;
		    }
		    return f;
	   }
	 public List<Chart> list(String name) { // ��ѯ������Ϣ


			List<Chart> list = new ArrayList<Chart>(); // ��������
			Connection conn = DBUtil.getConn();
			String sql = "select * from chart where name ='"+ name +"'"; // SQL��ѯ���

			try {

				PreparedStatement pst = conn.prepareStatement(sql);

				ResultSet rs = pst.executeQuery();
				
				Chart chart = null;
				
				while (rs.next()) {


					String weight = rs.getString("weight");

					

					

		                chart = new Chart(weight);
		            
		            list.add(chart);

				}

				rs.close(); // �ر�

				pst.close(); // �ر�

			} catch (SQLException e1) {

				e1.printStackTrace(); // �׳��쳣

			}

			return list; // ����һ������

		}

}