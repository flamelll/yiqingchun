package com.test.bean;

public class Zong implements Comparable<Zong>{
	private String name;
	private Integer zong;
	private String szong;
	public String getSzong() {
		return szong;
	}
	public void setSzong(String szong) {
		this.szong = szong;
	}
	public Zong (String name,int zong) {
		super();
		this.name=name;
		this.zong=zong;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getZong() {
		return zong;
	}
	public void setZong(Integer zong) {
		this.zong = zong;
	}
	@Override
	public String toString() {
		return "Zong [name=" + name + ", zong=" + zong + "]";
	}
 
	@Override
	public int compareTo(Zong o) {
		return this.zong.compareTo(o.getZong());
	}


	

}
