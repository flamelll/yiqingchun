package com.test.bean;

public class Chart {
	private String weight;
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public Chart(String weight){
		this.weight=weight;
	}
}
