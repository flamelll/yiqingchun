package com.test.service;

import com.test.dao.RegisterDao;
import com.test.bean.User;;

public class RegisterService {
private RegisterDao dao = new RegisterDao();
	
	/**
	 * �����û�ע��
	 * @param user
	 * @return
	 */
	public boolean register(User user) {
		boolean registerSuccess = false;
		
		registerSuccess = dao.register(user);//�ж��Ƿ�������ݿ�ɹ�
		
		return registerSuccess;
	}
}
