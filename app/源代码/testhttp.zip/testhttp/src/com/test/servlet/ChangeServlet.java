package com.test.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.test.bean.Shiwu;
import com.test.dao.*;
/**
 * Servlet implementation class DateServlet
 */
@WebServlet("/ChangeServlet")
public class ChangeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	LoginDao logindao = new LoginDao(); 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String npassword=request.getParameter("npassword");
		String a=null;
		System.out.println(name);
		System.out.println(password);
		System.out.println(npassword);
		String rname=logindao.searchUsername(name);
		String rpassword=logindao.searchPassword(name);
		PrintWriter pw=response.getWriter();


		if(name.equals(rname)&&password.equals(rpassword)) {

			ChangeDao.changePassword(name,npassword);
			a="�޸ĳɹ�";
			pw.write(a+","+name);
			pw.close();
		}
		else {
			a="�û������������";
			pw.write(a+",");
			pw.close();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}


