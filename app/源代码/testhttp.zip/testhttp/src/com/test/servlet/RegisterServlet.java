package com.test.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.bean.User;
import com.test.service.RegisterService;
import com.test.util.DBUtil;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private RegisterService Ser = new RegisterService();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
        response.setCharacterEncoding("utf-8");
        String a=null;
		String name = request.getParameter("phoneNum");     //getParameter()��ȡ���ǿͻ������õ����ݡ�
		String password = request.getParameter("password");
		String sql = "select name from user where ";
		if (name != "") {
			sql += "name like '%" + name + "%'";
		}
		Connection conn = DBUtil.getConn();
		Statement state = null;
		ResultSet rs = null;
		try {
			PrintWriter pw = response.getWriter();
			state = conn.createStatement();
			rs = state.executeQuery(sql);//executeQuery()���ذ���������ѯ���������ݵ� ResultSet ����,���û�в�ѯ����Ϣ������һ��next()Ϊfalse��ResultSet ����
			if(rs.next()==false) {
				User user = new User();
				user.setName(name);
				user.setPassword(password);
				System.out.println(" "+user.getName()+" "+user.getPassword());
				if(Ser.register(user)) {
					a="ע��ɹ�";
					pw.write(a+","+name);
					pw.close();
					
				}else {
					a="ע��ʧ��";
					pw.write(a+","+name);
					pw.close();
					
				}
			}
			else {
				a="ע��ʧ�ܣ��û��Ѵ���";
				pw.write(a+","+name);
				pw.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, state, conn);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
