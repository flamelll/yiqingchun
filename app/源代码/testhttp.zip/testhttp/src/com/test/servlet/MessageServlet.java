package com.test.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.DateDao;
import com.test.dao.MessageDao;

/**
 * Servlet implementation class MessageServlet
 */
@WebServlet("/MessageServlet")
public class MessageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MessageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("gbk");
		request.setCharacterEncoding("UTF-8");
	
        response.setContentType("text/html;charset=UTF-8");
        MessageDao dao = new MessageDao();
        String name=request.getParameter("name");
        String password=request.getParameter("password");
		String id=request.getParameter("id");
		String weight=request.getParameter("weight");
		String height=request.getParameter("height");
		String year=request.getParameter("year");
		String sex=request.getParameter("sex");
		String school=request.getParameter("school");
		System.out.println(name);
		System.out.println(password);
        System.out.println(id);
        System.out.println(weight);
        System.out.println(height);
        System.out.println(year);
        System.out.println(sex);
        System.out.println(school);
        dao.Message(name,password,id, weight, height, year, sex, school);
        
       
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
