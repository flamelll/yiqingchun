package com.test.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

import com.test.dao.DateShowDao;
import com.test.bean.Date;
import com.test.bean.Shiwu;
import com.test.bean.Zong;

/**
 * Servlet implementation class DateShowServlet
 */
@WebServlet("/DateShowServlet")
public class DateShowServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DateShowServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        DateShowDao dsd=new DateShowDao();
//        int t=0;
        List<Date> list = dsd.select();
        System.out.println(list);
        int j=0;
        List<String> list1 = new ArrayList<>();
        List<Date> list2 = new  ArrayList<>();
        List<Zong> list3 = new ArrayList<Zong>();
        for(Date date: list){
        	if(!list1.contains(date.getName())) {
        		list1.add(date.getName());
        	}
//        	j++;
        }
//        System.out.println("j:"+j);
        for(String s:list1) {
        	Zong z= new Zong(s, j);
        	z.setName(s);
        	z.setZong(0);
        	list3.add(z);
        }
        for(Zong z:list3) {
        	int t=0;
        for(Date date:list) {
        		if(date.getName().equals(z.getName())) {
        			String[] my =date.getTime().split(":");
        			int hour =Integer.parseInt(my[0]);
        			int min =Integer.parseInt(my[1]);
        			int sec =Integer.parseInt(my[2]);
        			int zong =hour*3600+min*60+sec;
        			t=t+zong;
//        			System.out.println(date.getName()+zong+"     "+t);
        		}
        	}
//        System.out.println("t:"+t);
        
        String str = String.valueOf(t);
        str = str+"��";
        z.setZong(t);
        z.setSzong(str);
        }
        Collections.sort(list3, new Comparator<Zong>() {
            public int compare(Zong o1, Zong o2) {
                //����
                return o1.getZong().compareTo(o2.getZong());
            }
        });
		System.out.println("���������--:"+list3.toString());
		
		Collections.sort(list3, new Comparator<Zong>() {
            public int compare(Zong o1, Zong o2) {
                //����
                return o2.getZong().compareTo(o1.getZong());
            }
        });
		System.out.println("���������--:"+list3.toString());
		
	
        int i=1;
        for(Zong z:list3) {
        	String ss = String.valueOf(i);
        	String rr =ss+"."+z.getName();
        	z.setName(rr);
        	i++;
        	System.out.println(z.getName()+":"+z.getZong()+"     "+z.getSzong());
        }
        
        String json = JSON.toJSONString(list3);
        System.out.println(json);
        PrintWriter pw=response.getWriter();
        pw.write(json);
		pw.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
