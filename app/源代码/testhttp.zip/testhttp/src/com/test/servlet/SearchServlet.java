package com.test.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.test.bean.Shiwu;
import com.test.dao.ShowDao;

import java.util.Base64;
import java.util.List;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("gbk");
        response.setContentType("text/html;charset=utf-8");
        response.setCharacterEncoding("utf-8");
        ShowDao sd = new ShowDao();
        String name=request.getParameter("name");
        
//        String str2 = new String(Base64.decode(name.getBytes(), Base64.DEFAULT));
//        String name="Easy";
        System.out.println(name);
        List<Shiwu> list = sd.select1(name);
        String json = JSON.toJSONString(list);
//      System.out.println(json);
      PrintWriter pw=response.getWriter();
      pw.write(json);
		pw.close();
//        String json1 = JSON.toJSONString(list);
        System.out.println(json);
        System.out.println("����SearchServlet");
//      request.setAttribute("list", list);
//      request.getRequestDispatcher("search.jsp").forward(request, response);
//        PrintWriter pw=response.getWriter();
//        pw.write(json1);
//		pw.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
