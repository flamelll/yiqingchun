package com.test.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.tomcat.util.codec.binary.Base64;

public class UploadImage {
	 public static void convertStringtoImage(String encodedImageStr, String fileName) {
	  try {
	   // Base64����ͼƬ
	   byte[] imageByteArray = Base64.decodeBase64(encodedImageStr);
	   File file = new File("C:/Program Files/Java/apache-tomcat-8.0.20/fileService/images/" + fileName+".jpg");
	   //�ж��Ƿ����
	   if (file.exists()) {
		System.out.println("file exists");
		file.delete();//���ھ�ɾ���ٴ���
		FileOutputStream imageOutFile = new FileOutputStream("C:/Program Files/Java/apache-tomcat-8.0.20/fileService/images/" + fileName+".jpg");//E:/java web/apache-tomcat-8.0.20/fileService/images/
		   imageOutFile.write(imageByteArray);
		   imageOutFile.close();
	   }else {
		   FileOutputStream imageOutFile = new FileOutputStream("C:/Program Files/Java/apache-tomcat-8.0.20/fileService/images/" + fileName+".jpg");//E:/java web/apache-tomcat-8.0.20/fileService/images/
		   imageOutFile.write(imageByteArray);
		   imageOutFile.close();
	   }
	   System.out.println("Image Successfully Stored");
	  } catch (FileNotFoundException fnfe) {
	   System.out.println("Image Path not found" + fnfe);
	  } catch (IOException ioe) {
	   System.out.println("Exception while converting the Image " + ioe);
	  }
	 }
	}